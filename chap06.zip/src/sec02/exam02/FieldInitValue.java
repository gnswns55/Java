package sec02.exam02;

public class FieldInitValue {
	//�ʵ�
	byte byteField;
	short shortField;
	int intField;
	long longField;
	
	boolean booleanField;
	char charField;	
	
	float floatField;
	double doubleField;
	
	int[]  arrField;
	String referenceField;	
}

