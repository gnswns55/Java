package sec02.verify.exam03;

public class MemberExample {
	public static void main(String[] args) {
		Member member = new Member();
		member.name = "���Ͼ�";
		member.age = 23;
	}
}
