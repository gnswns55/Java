module chap06 {
	requires java.se;	
}