package sec06.exam01;

public class Car {

}
