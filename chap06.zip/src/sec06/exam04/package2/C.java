package sec06.exam04.package2;

import sec06.exam04.package1.A;

public class C {
	// �ʵ�
	A a1 = new A(true);
	// A a2 = new A(1);
	// A a3 = new A("���ڿ�");
}
