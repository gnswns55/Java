package sec02.exam01;

public class Person {
	void wake() {
		System.out.println("7�ÿ� �Ͼ�ϴ�.");
	}
}
