package sec02.exam04;

public interface Calculatable {
	public int sum();
}
