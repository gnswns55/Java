package sec01.verify.exam03;

public class Car {
	class Tire {}
	static class Engine {}
}
