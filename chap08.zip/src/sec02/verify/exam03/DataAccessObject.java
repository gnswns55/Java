package sec02.verify.exam03;

public interface DataAccessObject {
	public void select();
	public void insert();
	public void update();
	public void delete();
}
