package sec02.exam01;

public interface Tire {
	public void roll();
}
