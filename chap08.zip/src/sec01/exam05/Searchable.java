package sec01.exam05;

public interface Searchable {
	void search(String url);
}
