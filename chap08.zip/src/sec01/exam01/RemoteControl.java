package sec01.exam01;

public interface RemoteControl {

}
