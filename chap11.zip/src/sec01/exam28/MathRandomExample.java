package sec01.exam28;

public class MathRandomExample {
	public static void main(String[] args) {
		int num = (int) (Math.random()*6) + 1;
		System.out.println("�ֻ��� ��: " + num);
	}
}
