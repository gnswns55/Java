package sec02.exam06;

public class Parent {
}
