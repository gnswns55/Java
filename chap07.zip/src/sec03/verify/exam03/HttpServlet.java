package sec03.verify.exam03;

public abstract class HttpServlet {
	public abstract void service();
}
