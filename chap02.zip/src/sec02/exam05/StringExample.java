package sec02.exam05;

public class StringExample {
	public static void main(String[] args) {
		String name = "ȫ�浿";
		String job = "���α׷���";
		System.out.println(name);
		System.out.println(job);
	} 
}

