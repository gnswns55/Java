package sec03.verify.exam02;

public enum LoginResult {
	SUCCESS,
	FAIL_ID,
	FAIL_PASSWORD
}
